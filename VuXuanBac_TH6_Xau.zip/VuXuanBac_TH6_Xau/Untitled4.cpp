#include <iostream>
#include <string>
#include <vector>
#include <sstream>
using namespace std;

// Hàm tính mảng Z cho xâu S
vector<int> tinhZ(const string &S) {
    int n = S.size();
    vector<int> Z(n, 0);
    int L = 0, R = 0;
    for (int i = 1; i < n; i++) {
        if (i <= R)
            Z[i] = min(R - i + 1, Z[i - L]);
        while (i + Z[i] < n && S[Z[i]] == S[i + Z[i]])
            Z[i]++;
        if (i + Z[i] - 1 > R) {
            L = i;
            R = i + Z[i] - 1;
        }
    }
    return Z;
}

int main() {
    string vanban;
    cout << "Nhap doan van ban (toi da 50 tu):\n";
    getline(cin, vanban);

    // Tách từ đầu tiên
    stringstream ss(vanban);
    string tudautien;
    ss >> tudautien;

    // Ghép từ đầu tiên + ký tự đặc biệt + văn bản
    string S = tudautien + "$" + vanban;

    // Tính mảng Z
    vector<int> Z = tinhZ(S);

    // Đếm số lần xuất hiện
    int dem = 0;
    int dodai = tudautien.size();
    for (int i = dodai + 1; i < (int)S.size(); i++) {
        if (Z[i] >= dodai) dem++;
    }

    cout << "Tu dau tien la: \"" << tudautien << "\"\n";
    cout << "So lan xuat hien: " << dem << endl;

    return 0;
}
