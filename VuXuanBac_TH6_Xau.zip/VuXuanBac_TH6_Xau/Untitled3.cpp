#include <iostream>
#include <string>
#include <vector>
using namespace std;

// Hàm xây dựng bảng dịch chuyển cho BMH
void buildShiftTable(const string &pattern, vector<int> &shift) {
    int m = pattern.size();
    int ALPHABET_SIZE = 256; // ASCII
    shift.assign(ALPHABET_SIZE, m); // mặc định dịch = độ dài pattern

    for (int i = 0; i < m - 1; i++) {
        shift[(unsigned char)pattern[i]] = m - 1 - i;
    }
}

// Hàm tìm kiếm theo Boyer-Moore-Horspool
vector<int> BMHSearch(const string &text, const string &pattern) {
    vector<int> positions;
    if (pattern.empty() || text.empty()) return positions;

    int n = text.size();
    int m = pattern.size();
    vector<int> shift;
    buildShiftTable(pattern, shift);

    int i = 0;
    while (i <= n - m) {
        int j = m - 1;
        while (j >= 0 && pattern[j] == text[i + j]) {
            j--;
        }
        if (j < 0) {
            positions.push_back(i); // tìm thấy
            i += m; // dịch tiếp theo sau đoạn tìm thấy
        } else {
            i += shift[(unsigned char)text[i + m - 1]];
        }
    }

    return positions;
}

int main() {
    string s = "toi co 1000, Nam co 21000, Dong co 1000 va 500";
    string pattern = "1000";
    string replaceStr = "mot nghin";

    cout << "Xau ban dau: " << s << endl;

    // Tìm tất cả vị trí xuất hiện
    vector<int> found = BMHSearch(s, pattern);
    cout << "So lan xuat hien \"" << pattern << "\": " << found.size() << endl;

    // Thay thế từ cuối về đầu để không làm sai lệch vị trí
    for (int i = found.size() - 1; i >= 0; i--) {
        s.replace(found[i], pattern.size(), replaceStr);
    }

    cout << "Xau sau khi thay the: " << s << endl;

    return 0;
}
