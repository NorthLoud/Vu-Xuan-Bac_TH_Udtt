#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

// Hàm cộng 2 số nguyên lớn
string congSoLon(string a, string b) {
    // Đảm bảo a luôn là số dài hơn hoặc bằng b
    if (a.size() < b.size()) swap(a, b);

    // Đảo ngược chuỗi để cộng từ cuối
    reverse(a.begin(), a.end());
    reverse(b.begin(), b.end());

    string ketqua = "";
    int nho = 0;  // biến nhớ
    for (int i = 0; i < a.size(); i++) {
        int so1 = a[i] - '0';
        int so2 = (i < b.size()) ? (b[i] - '0') : 0;

        int tong = so1 + so2 + nho;
        ketqua.push_back(tong % 10 + '0');
        nho = tong / 10;
    }

    if (nho > 0) ketqua.push_back(nho + '0');

    // Đảo ngược lại kết quả
    reverse(ketqua.begin(), ketqua.end());
    return ketqua;
}

int main() {
    string m, n;
    cout << "Nhap so nguyen duong m: ";
    cin >> m;
    cout << "Nhap so nguyen duong n: ";
    cin >> n;

    string tong = congSoLon(m, n);

    cout << "Tong cua m + n = " << tong << endl;
    return 0;
}
