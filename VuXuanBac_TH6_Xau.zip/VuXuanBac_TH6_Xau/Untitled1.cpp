#include <iostream>
#include <cstring>
using namespace std;

// Hàm kiểm tra xâu có đối xứng hay không
bool laDoiXung(char s[]) {
    int trai = 0;
    int phai = strlen(s) - 1;
    while (trai < phai) {
        if (s[trai] != s[phai]) return false;
        trai++;
        phai--;
    }
    return true;
}

// Hàm tìm xâu con đối xứng dài nhất có tâm là s[k]
void timXauConDoiXung(char s[], int k) {
    int n = strlen(s);
    int trai = k, phai = k;
    int maxTrai = k, maxPhai = k;

    // Mở rộng sang 2 phía
    while (trai >= 0 && phai < n && s[trai] == s[phai]) {
        maxTrai = trai;
        maxPhai = phai;
        trai--;
        phai++;
    }

    cout << "Xau con doi xung dai nhat co tam la s[" << k << "] = '" << s[k] << "': ";
    for (int i = maxTrai; i <= maxPhai; i++) cout << s[i];
    cout << endl;
    cout << "Do dai: " << (maxPhai - maxTrai + 1) << endl;
}

int main() {
    char s[100];
    cout << "Nhap xau ky tu: ";
    cin >> s;

    if (laDoiXung(s)) {
        cout << "Xau \"" << s << "\" la xau doi xung." << endl;
    } else {
        cout << "Xau \"" << s << "\" KHONG la xau doi xung." << endl;
        int k;
        cout << "Nhap vi tri k (0.." << strlen(s)-1 << "): ";
        cin >> k;
        if (k >= 0 && k < strlen(s)) {
            timXauConDoiXung(s, k);
        } else {
            cout << "Vi tri k khong hop le!" << endl;
        }
    }
    return 0;
}
