#include <iostream>
#include <string>
using namespace std;

int main() {
    string vanBan;
    cout << "Nhap doan van ban tieng Anh (toi da 50 tu):\n";
    getline(cin, vanBan);

    string tuCanTim = "child";
    string tuThayThe = "children";
    int dem = 0;

    // Duyệt vét cạn từng vị trí để tìm "child"
    for (int i = 0; i + tuCanTim.size() <= vanBan.size(); i++) {
        bool giong = true;
        for (int j = 0; j < tuCanTim.size(); j++) {
            if (vanBan[i + j] != tuCanTim[j]) {
                giong = false;
                break;
            }
        }
        if (giong) {
            dem++;
            // Thay thế trực tiếp bằng erase + insert
            vanBan.erase(i, tuCanTim.size());
            vanBan.insert(i, tuThayThe);
            // Sau khi thay, lùi lại i để tránh bỏ sót (vì độ dài thay đổi)
            i += tuThayThe.size() - 1;
        }
    }

    cout << "So lan xuat hien tu \"" << tuCanTim << "\": " << dem << endl;
    cout << "Doan van sau khi thay the: " << vanBan << endl;

    return 0;
}
