#include<bits/stdc++.h>
using namespace std; 

char nguoi[4][10]={"tung", "cuc", "truc", "mai"};
int a[4] , used[4], dem = 0;

void xuat(){
	dem++;
	cout<<"Cach"<<dem<<":";										
	for(int i=0; i<4; i++)										// duyệt 4 ghế
		cout<<"Ghe"<<char('A'+i)<<": "<<nguoi[a[i]]<<" ";		// bien chi so 0 -> 3 đại diện A ->D
	cout<<endl;													// a[i] (là chỉ số ng ngoi ghe thu i)
}																// nguoi[a[i]] (lấy ten người tuong ứng)
void Try(int i){
	for(int j=0; j<4; j++){										// thử gán ng j cho ghế i				
		if (!used[j]){											// nếu ng j chưa dc dùng trong tổ hợp hiện tại
			a[i] = j;											// gán ng j cho ghế i
			used[j]=1;											// đánh dấu ng j đã dc dùng									
			if (i==3) xuat();									// xếp đủ 4 -> in
			else Try(i+1);										// nếu 0, đệ quy xếp ng tiếp cho ghế tiếp
			used[j] = 0;										// bỏ đánh dấu để thử các phương án khác
		}
	}
}

int main(){
	Try(0);
	cout<<"Tong so cach xep: "<<dem <<endl;
	return 0;
}

/*
Có 4 người {A, B, C, D}
Có 4 ghế {1, 2, 3, 4}
Mỗi ghế nhận đúng 1 người và không lặp lại
 	Tổng số hoán vị: P(4,4)=4!=24
 	
- Mảng a[] để lưu chỉ số người được xếp
- Mảng used[] để đánh dấu người đã được chọn
- Mỗi bước đệ quy i chọn người cho ghế thứ i

Đệ quy:
- Gọi Try(i) → thử người cho ghế thứ i
- Nếu i == 3 (vị trí cuối), in kết quả
- Với mỗi j từ 0 → 3:
- Nếu used[j] == 0 → chọn j cho a[i]
- Gọi đệ quy tiếp Try(i+1)
- Sau đó backtrack used[j] = 0
*/