#include<bits/stdc++.h>
using namespace std;

char S[7] = {'A', 'B', 'C', 'D', 'E', 'F', 'G'};
int a[6], dem = 0;

void xuat(){
	dem++;											// tăng sl to hop da in
	cout<<"To hop "<<dem<<": ";
	for(int i =0; i<6; i++)							// duyet mang a[] chua chi so ky tu dc chon 
		cout<<S[a[i]]<<" ";							// Lay ky tu tuong ung từ mảng S -> in
	cout<<endl;
}

void Try(int i, int start){							// i(vtri htai 0-5), start(chi so băt dau chon cho ptu htai)
	for(int j = start; j<7; j++){					// j(chi so của S[j] dc thêm vào to hop)
		a[i]=j;										// gán chỉ số j dc chọn và ptu i 
		if(i==5) xuat();							// đủ 6 -> in
		else Try(i+1, j+1); 						// chưa đủ -> tiếp tụ đệ quy, dùng j +1 để ko bị trùng
	}
}

int main(){
	Try(0,0);
	cout<<"Tong so cach lay: "<<dem<<endl;
	return 0;
}

/*
Cho tập S = {A, B, C, D, E, F, G}
Chọn ra 6 phần tử khác nhau từ S
		Tổng số cách chọn: C(7,6)=7

- Mảng a[] lưu chỉ số ký tự được chọn
- Tại mỗi bước i, chọn chỉ số từ start → 6
- Tăng start để tránh lặp tổ hợp

Đệ quy:
- Gọi Try(i, start):
- Với mỗi j từ start → 6:
- Gán a[i] = j
- Nếu đủ 6 phần tử → in tổ hợp
- Ngược lại → gọi Try(i+1, j+1)
*/




