#include<bits/stdc++.h>
using namespace std;

struct ChuyenBay{
	char ma[10];
	long gia;
	int ghe;
};

const int n=6;
ChuyenBay ds[n]= {
	{"Vn001", 800000, 150},
	{"Vn002", 500000, 120},
	{"Vn003", 750000, 100},
	{"Vn004", 1000000, 180},
	{"Vn005", 670000, 110},
	{"Vn006", 900000, 130}
};

void hienThi(ChuyenBay cb){
	cout<< cb.ma<<" - Gia: "<<cb.gia<<" - Ghe:"<<cb.ghe<<endl;
}
void hienThiLonHon(ChuyenBay a[], int i){
	if(i>= n) return; 							    // dừng đệ quy khi hết danh sách
	if (a[i].gia>700000)
		hienThi(a[i]);
	hienThiLonHon(a, i+1);						    // đệ quy sang phần tử kế tiếp
}

ChuyenBay chuyenMin(ChuyenBay a[], int l, int r){
	if (l==r) return a[l];							// nếu có 1 ptu thì trả về chính nó
	int m = (l+r)/2;								// chia làm 2 dãy
	ChuyenBay left = chuyenMin(a, l, m);			// min trái
	ChuyenBay right = chuyenMin(a, m+1, r);			// min phải
	return (left.gia< right.gia) ? left : right;	// trả về thấp nhất
}

// Chọn 4 chuyến bay = quay lui
int a4[4], demToHop = 0;	
void xuatToHop(){
	demToHop++;										// tăng phương án lên
	cout<< "Phuong an"<<demToHop<<": ";
	for(int i= 0; i<4; i++){
		cout<<ds[a4[i]].ma<<" ";					// Lấy mã chuyến bay từ mảng ds tại chỉ số a4[i]
	}
	cout <<endl;
}
void Try4(int i, int start){						
	for(int j = start; j<n; j++){				
		a4[i]=j;									//lưu chỉ số được chọn vào vị trí thứ i
		if(i==3) xuatToHop();						// đủ 4 ptu -> in
		else Try4(i+1, j+1);						// chọn ptu tiếp từ j+1 để ko bị trùng
	}
}

int main(){
	cout<<"\nCac chuyen bay co gia > 700000:\n";
	hienThiLonHon(ds, 0);
	ChuyenBay minCB =  chuyenMin(ds, 0, n-1);
	cout<<"\nChuyen bay co gia thap nhat:\n";
	hienThi(minCB);
	cout <<"\nTat ca phuong an chon 4 chuyen bay:\n";
	Try4(0,0);											// bắt đầu sinh tổ hợp 4 chuyến bay
	cout<<"Tong phuong an: "<<demToHop<<endl;
	return 0;
}

/*
b, 
- Mỗi lần xét 1 phần tử ở chỉ số i
- Nếu gia > 700000 thì in
- Gọi tiếp với i+1
c, 
- Chia mảng thành 2 nửa: [l..m] và [m+1..r]
- Tìm min bên trái, min bên phải
- So sánh 2 min → trả min nhỏ hơn
d, 
- Chọn 4 phần tử khác nhau từ 6–10 chuyến bay → tổ hợp C(n, 4)
- Sử dụng đệ quy sinh tổ hợp
- Gọi a[0..3] là chỉ số chuyến bay:
	a[0] < a[1] < a[2] < a[3]
	Mỗi Try(i, start) chọn chỉ số từ start → n-1
*/




























