#include<bits/stdc++.h>
using namespace std;

struct CongViec {
	char ma[10];
	int batDau;  //Theo gio
	int thoiGian;   //Theo phut
};
const int n=6;
CongViec ds[n] = {
	{"Cv01", 8, 90},
	{"Cv02", 9, 60},
	{"Cv03", 10, 120},
	{"Cv04", 13, 45},
	{"Cv05", 14, 30},
	{"Cv06", 15, 75}
};

void hienThi(CongViec cv){
	cout<<cv.ma<< " - Bat dau: "<<cv.batDau <<" - TG: "<<cv.thoiGian<<"p\n";
}
void hienThiNguoc(CongViec a[], int i){						
	if (i<0) return;									// dk dừng khi vượt qua chỉ số 0
	hienThi(a[i]);										// in cv tại vtri i
	hienThiNguoc(a, i-1);								// gọi lại ptu trc 
}

int a5[5], dem5 = 0;
void xuatCV(){
	dem5++;
	cout<<"Phuong an "<<dem5<<": ";
	for (int i=0; i<5; i++)
		cout<<ds[a5[i]].ma<<" ";						// Lấy mã cv từ mảng ds tại chỉ số a5[i]
	cout<<endl;
}
void Try5(int i, int start ){
	for (int j = start; j<n; j++){
		a5[i]=j;
		if(i==4) xuatCV();								// đủ 5 -> in
		else Try5(i+1, j+1);							// chọn ptu tiếp từ j+1 để ko bị trùng
	}
}

int main(){
	cout<<"Danh sach cong viec theo thu tu nguoc: \n";
	hienThiNguoc(ds, n-1);
	cout<<"\nTat ca cach chon 5 cong viec: \n";
	Try5(0, 0);
	cout <<"Tong so cach: "<< dem5<<endl;
	return 0;
}

/*
b, 
- In phần tử cuối trước, rồi lui dần
- Gọi i = n - 1 → 0
c, 
-Chọn tổ hợp 5 công việc từ 6–10 cái
- Không cần in nội dung, chỉ in ma
*/






















