#include <iostream>
using namespace std;

int main() {
    int n = 6; // số gói hàng (có thể thay đổi >= 6)
    int w[10] = {0, 2, 3, 4, 5, 9, 7}; // trọng lượng (w[0] = 0 bỏ qua)
    int v[10] = {0, 3, 4, 8, 8, 10, 6}; // giá trị (v[0] = 0 bỏ qua)

    int m;
    cout << "Nhap suc chua toi da cua tui (m): ";
    cin >> m;

    // Bảng DP
    int dp[20][100]; // dp[i][j] = giá trị lớn nhất với i gói đầu, sức chứa j
    bool take[20][100]; // đánh dấu chọn gói hàng

    for (int i = 0; i <= n; i++) {
        for (int j = 0; j <= m; j++) {
            dp[i][j] = 0;
            take[i][j] = false;
        }
    }

    // Quy hoạch động
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            dp[i][j] = dp[i-1][j]; // không lấy gói i
            if (w[i] <= j && dp[i-1][j-w[i]] + v[i] > dp[i][j]) {
                dp[i][j] = dp[i-1][j-w[i]] + v[i];
                take[i][j] = true;
            }
        }
    }

    // Truy vết gói hàng được chọn
    int j = m;
    int danhSach[20], soLuong = 0;
    for (int i = n; i > 0; i--) {
        if (take[i][j]) {
            danhSach[soLuong++] = i; // lưu số thứ tự gói hàng
            j -= w[i];
        }
    }

    // Kết quả
    cout << "\n--- Ket qua ---\n";
    cout << "Gia tri lon nhat: " << dp[n][m] << "\n";
    cout << "Cac goi hang duoc chon:\n";
    for (int k = soLuong-1; k >= 0; k--) {
        int i = danhSach[k];
        cout << "Goi " << i << "  (Trong luong = " << w[i] 
             << ", Gia tri = " << v[i] << ")\n";
    }
    cout << "Tong so goi hang duoc chon: " << soLuong << "\n";

    return 0;
}
