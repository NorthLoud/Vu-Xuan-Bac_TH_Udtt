#include <bits/stdc++.h>
using namespace std;

const int MAX = 10005; // giới hạn m

int main() {
    int n; // số loại tiền
    int menh_gia[100]; // mảng chứa các mệnh giá
    int so_tien; // số tiền cần đổi

    // Khởi tạo dữ liệu
    cout << "Nhap so loai tien n: ";
    cin >> n;
    cout << "Nhap cac menh gia (tang dan): ";
    for (int i = 1; i <= n; i++) {
        cin >> menh_gia[i];
    }
    cout << "Nhap so tien can doi: ";
    cin >> so_tien;

    // Mảng f lưu số tờ ít nhất, khởi tạo lớn
    int f[MAX];
    int truy_vet[MAX]; // để nhớ loại tiền nào đã dùng

    for (int i = 0; i <= so_tien; i++) {
        f[i] = 1e9; // vô cùng
        truy_vet[i] = -1;
    }

    f[0] = 0; // đổi 0 đồng thì cần 0 tờ

    // Quy hoạch động
    for (int x = 1; x <= so_tien; x++) {
        for (int i = 1; i <= n; i++) {
            if (x >= menh_gia[i] && f[x - menh_gia[i]] + 1 < f[x]) {
                f[x] = f[x - menh_gia[i]] + 1;
                truy_vet[x] = i; // lưu lại loại tiền
            }
        }
    }

    if (f[so_tien] == 1e9) {
        cout << "Khong the doi duoc so tien nay!\n";
    } else {
        cout << "Tong so to tien it nhat: " << f[so_tien] << endl;

        // Đếm số tờ của từng loại
        int dem[100] = {0};
        int x = so_tien;
        while (x > 0) {
            int i = truy_vet[x]; // lấy loại tiền i
            if (i == -1) break; // không thể truy vết
            dem[i]++;
            x -= menh_gia[i];
        }

        cout << "Cac loai menh gia duoc su dung:\n";
        for (int i = 1; i <= n; i++) {
            if (dem[i] > 0) {
                cout << "Menh gia " << menh_gia[i] << ": " << dem[i] << " to\n";
            }
        }
    }

    return 0;
}
