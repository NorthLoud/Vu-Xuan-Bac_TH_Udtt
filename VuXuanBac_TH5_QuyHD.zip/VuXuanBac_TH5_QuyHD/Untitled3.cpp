#include <iostream>
using namespace std;

int main() {
    int n = 15; // số phần tử (có thể thay đổi >= 15)
    double A[105] = {5, 2, 8, 6, 3, 6, 9, 7, 10, 15, 1, 11, 4, 12, 14};
    
    int dp[105];       // dp[i] = độ dài LIS kết thúc tại i
    int truoc[105];    // lưu chỉ số phần tử đứng trước trong LIS
    for (int i = 0; i < n; i++) {
        dp[i] = 1;
        truoc[i] = -1;
    }

    int maxLen = 1;
    int viTriMax = 0;

    // Tính dp
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            if (A[j] < A[i] && dp[j] + 1 > dp[i]) {
                dp[i] = dp[j] + 1;
                truoc[i] = j;
            }
        }
        if (dp[i] > maxLen) {
            maxLen = dp[i];
            viTriMax = i;
        }
    }

    // Truy vết dãy con
    double ketQua[105];
    int k = 0;
    int x = viTriMax;
    while (x != -1) {
        ketQua[k++] = A[x];
        x = truoc[x];
    }

    // In kết quả
    cout << "--- Ket qua ---\n";
    cout << "Do dai LIS: " << maxLen << "\n";
    cout << "Day con: ";
    for (int i = k-1; i >= 0; i--) {
        cout << ketQua[i] << " ";
    }
    cout << "\n";

    return 0;
}
