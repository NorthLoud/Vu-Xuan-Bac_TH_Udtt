#include <iostream>
using namespace std;

// ----------- QUY HOẠCH ĐỘNG: Đếm số cách ---------------
int demCach(int n, int m) {
    int dp[105][105];

    // Khởi tạo
    for (int i = 0; i <= n; i++) {
        for (int j = 0; j <= m; j++) {
            dp[i][j] = 0;
        }
    }
    for (int j = 0; j <= m; j++) dp[0][j] = 1;

    // Quy hoạch động
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            dp[i][j] = dp[i][j-1];
            if (i >= j) dp[i][j] += dp[i-j][j];
        }
    }
    return dp[n][m];
}

// ----------- QUAY LUI: Liệt kê các cấu hình ---------------
int ketQua[105];
int dem = 0;

void lietKe(int n, int m, int idx) {
    if (n == 0) {
        cout << ++dem << ": ";
        for (int i = 0; i < idx; i++) {
            cout << ketQua[i];
            if (i < idx-1) cout << " + ";
        }
        cout << "\n";
        return;
    }
    for (int i = (n < m ? n : m); i >= 1; i--) {
        ketQua[idx] = i;
        lietKe(n - i, i, idx + 1);
    }
}

// ----------- MAIN ---------------
int main() {
    int n, m;
    cout << "Nhap n, m: ";
    cin >> n >> m;

    cout << "\nSo cach phan tich (quy hoach dong): " << demCach(n, m) << "\n";

    cout << "\nCac cau hinh (quay lui):\n";
    dem = 0;
    lietKe(n, m, 0);

    return 0;
}
